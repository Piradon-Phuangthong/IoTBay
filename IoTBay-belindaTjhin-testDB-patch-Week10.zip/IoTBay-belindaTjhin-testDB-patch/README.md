# IoTBay

**Case study:** IoTBay is an Internet of Things store that would like to develop an online IoT devices ordering application for customers to purchase these devices. The following program is a prototype for the register/login/logout features of the application as part of R0. 


